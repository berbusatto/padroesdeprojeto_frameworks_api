public interface CalculaInterface {
    public double soma(double n1, double n2);
    public double subtrai(double n1, double n2);
    public double multiplica(double n1, double n2);
    public double divide(double n1, double n2);
}
